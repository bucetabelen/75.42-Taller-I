extern crate sha1;

use sha1::{Digest, Sha1};

/// Takes an array of bytes a performs a Sha1 hash on it,
/// returning the generated hash as a vector of bytes
///
/// # Example
///
/// ```no_run
/// use rusty_krab_torrent::torrent::hash::sha;
///
/// let hash: Vec<u8> = sha("hello world".as_bytes());
///
/// assert_eq!(hash, vec![42, 174, 108, 53, 201, 79, 207, 180, 21, 219, 233, 95, 64, 139, 156, 233, 30, 232, 70, 237]);
/// ```
pub fn sha(b: &[u8]) -> Vec<u8> {
    let mut hasher = Sha1::new();
    hasher.update(b);
    let result = hasher.finalize();
    result.to_vec()
}

/// Takes a hash sha1 as a byte array and returns a string
/// with each byte in two-digit hexadecimal separated by %
///
/// in case of empty vector it will return empty string
///
/// # Example
///
/// ```
///  use rusty_krab_torrent::torrent::hash::to_string;
///  let hash = to_string(&[0, 1, 15, 255, 240]);
///  assert_eq!(hash, "%00%01%0f%ff%f0");
///
///
///
///  let hash = to_string(&[]);
///  assert_eq!(hash, "");
/// ```
pub fn to_string(b: &[u8]) -> String {
    let strs: Vec<String> = b.to_vec().iter().map(|b| format!("%{:02x}", b)).collect();

    strs.join("")
}

#[cfg(test)]
mod sha_tests {
    use super::{sha, to_string};

    #[test]
    fn make_sha_test() {
        let hash: Vec<u8> = sha(&"hello world".as_bytes());
        assert_eq!(
            hash,
            vec![
                42, 174, 108, 53, 201, 79, 207, 180, 21, 219, 233, 95, 64, 139, 156, 233, 30, 232,
                70, 237
            ]
        );
        let hash2: Vec<u8> = sha(&[0]);
        assert_eq!(
            hash2,
            vec![
                91, 169, 60, 157, 176, 207, 249, 63, 82, 181, 33, 215, 66, 14, 67, 246, 237, 162,
                120, 79
            ]
        );
    }

    #[test]
    fn make_sha_to_string_test() {
        let hash: Vec<u8> = sha(&[0]);
        let str_hash = to_string(&hash);
        assert_eq!(
            str_hash,
            "%5b%a9%3c%9d%b0%cf%f9%3f%52%b5%21%d7%42%0e%43%f6%ed%a2%78%4f".to_string()
        );
    }

    #[test]
    fn hash_vec_to_string_test() {
        let hash: Vec<u8> = vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
        let str_hash = to_string(&hash);
        assert_eq!(
            str_hash,
            "%00%01%02%03%04%05%06%07%08%09%0a%0b%0c%0d%0e%0f".to_string()
        );
        let hash2: Vec<u8> = vec![
            16, 32, 48, 64, 80, 96, 112, 128, 144, 160, 176, 192, 208, 224, 240,
        ];
        let str_hash2 = to_string(&hash2);
        assert_eq!(
            str_hash2,
            "%10%20%30%40%50%60%70%80%90%a0%b0%c0%d0%e0%f0".to_string()
        );
        let hash3: Vec<u8> = Vec::new();
        let str_hash3 = to_string(&hash3);
        assert_eq!(str_hash3, "".to_string());
    }
}
