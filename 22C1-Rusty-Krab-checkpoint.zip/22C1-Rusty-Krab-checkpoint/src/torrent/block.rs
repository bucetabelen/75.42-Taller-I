#[derive(Debug, PartialEq)]
pub struct Block {
    pub index: u32,
    pub length: u32,
    pub data: Option<Vec<u8>>,
}

/// Represents a portion of data that a client may request from a peer.
impl Block {
    pub fn new(index: u32, length: u32) -> Self {
        Block {
            index,
            length,
            data: None,
        }
    }
}

#[cfg(test)]
mod tests {

    use crate::torrent::block::Block;
    #[test]
    fn test_block_creation() {
        let block: Block = Block::new(0, 20);
        assert_eq!(
            block,
            Block {
                index: 0,
                length: 20,
                data: None
            }
        );
    }
}
