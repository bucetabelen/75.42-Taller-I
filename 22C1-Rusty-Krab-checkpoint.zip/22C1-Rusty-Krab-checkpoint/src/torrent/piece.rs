use std::{
    fs::File,
    io::{self, Seek, Write},
};

use crate::{torrent::block::Block, torrent::hash::sha, utils::error::TorrentError};

pub static BLOCK_SIZE: usize = 16384; // 2^14

/// Represents a Piece of the file to be downloaded, where a Piece is made of many Blocks
#[derive(Debug, PartialEq)]
pub struct Piece {
    pub length: usize,
    pub piece_length: usize,
    pub index: u32,
    pub blocks: Vec<Block>,
    pub hash: Vec<u8>,
    pub is_complete: bool,
}

/// Represents a portion of the data to be downloaded which is described in the metainfo file and
/// can be verified by a SHA1 hash. A piece is made up of blocks
impl Piece {
    pub fn new(length: usize, index: u32, piece_length: usize, hash: Vec<u8>) -> Self {
        let mut blocks: Vec<Block> = vec![];
        let num_blocks = ((length as f64) / (BLOCK_SIZE as f64)).ceil() as usize;

        for i in 0..num_blocks {
            let block_length = {
                if i < num_blocks - 1 {
                    BLOCK_SIZE
                } else {
                    length - (BLOCK_SIZE * (num_blocks - 1))
                }
            };

            let block = Block::new(i as u32, block_length as u32);
            blocks.push(block);
        }

        Piece {
            length,
            piece_length,
            index,
            hash,
            blocks,
            is_complete: false,
        }
    }

    /// looks for a block that is missing to complete and returns it,
    /// in case none is missing it returns None
    pub fn next_block_to_request(&self) -> Option<&Block> {
        if self.is_complete {
            return None;
        }

        for block in self.blocks.iter() {
            if block.data.is_none() {
                return Some(block);
            }
        }

        None
    }

    /// given a file, a block position, and a byte array
    /// sets the vector data in the blocks of the part
    /// if all the blocks are available, the sha1 is analyzed,
    /// if it does not correspond, it eliminates the changes in the blocks of the piece,
    /// if it corresponds, it writes the file with the corresponding data
    ///
    /// file writing may fail and return an error
    ///
    /// If it works correctly, nothing more than an Ok(()) will be returned.
    pub fn store(
        &mut self,
        file: &mut File,
        block_index: u32,
        data: Vec<u8>,
    ) -> Result<(), TorrentError> {
        let block = &mut self.blocks[block_index as usize];
        block.data = Some(data);

        if self.have_all_blocks() {
            // concatenate data from blocks together bc we have all the blocks
            let mut data = vec![];
            for block in self.blocks.iter() {
                println!("Downloading block {}\n", block.index);
                data.extend(block.data.clone().unwrap());
            }

            // validate that piece data downloaded matches SHA1 hash

            if self.hash == sha(&data) {
                println!("Piece {} is complete :) and validated:\n", self.index);
                println!("Metainfo hash: {:?}\n", self.hash);
                println!("Our hash: {:?}\n", sha(&data));
                let offset = self.index as u64 * self.piece_length as u64;
                (file.seek(io::SeekFrom::Start(offset)))?;
                (file.write_all(&data))?;
                self.delete_data();
                self.is_complete = true;
            } else {
                println!("Piece is corrupt, deleting downloaded piece data!");
                println!("We want {:?}", self.hash);
                println!("But Got {:?}", sha(&data));
                self.delete_data();
            }
        }
        Ok(())
    }

    /// set all blocks to None of a piece
    pub fn delete_data(&mut self) {
        for block in self.blocks.iter_mut() {
            block.data = None;
        }
    }

    /// if it has all the blocks it returns true, in case any block is None it returns false
    pub fn have_all_blocks(&self) -> bool {
        for block in self.blocks.iter() {
            if block.data.is_none() {
                return false;
            }
        }
        true
    }
}

#[cfg(test)]
mod tests {
    use super::Piece;
    use crate::torrent::block::Block;

    #[test]
    fn test_piece_creation() {
        let p = Piece::new(256, 4, 4, vec![1, 2, 3]);
        assert_eq!(
            p,
            Piece {
                length: 256,
                piece_length: 4,
                index: 4,
                blocks: vec![Block::new(0, 256)],
                hash: vec![1, 2, 3],
                is_complete: false,
            }
        );
    }

    #[test]
    fn test_clear_block() {
        let mut p1 = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![Block {
                index: 0,
                length: 1,
                data: Some(Vec::new()),
            }],
            hash: vec![],
            is_complete: false,
        };
        assert_eq!(true, p1.have_all_blocks());
        p1.delete_data();
        assert_eq!(false, p1.have_all_blocks());
    }

    #[test]
    fn test_have_all_blocks() {
        let p = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![],
            hash: vec![],
            is_complete: false,
        };
        assert!(p.have_all_blocks());
        let p1 = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![Block {
                index: 0,
                length: 0,
                data: None,
            }],
            hash: vec![],
            is_complete: false,
        };
        assert_eq!(false, p1.have_all_blocks());
        let p2 = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![Block {
                index: 0,
                length: 1,
                data: Some(Vec::new()),
            }],
            hash: vec![],
            is_complete: false,
        };
        assert!(p2.have_all_blocks());
        let p3 = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![
                Block {
                    index: 0,
                    length: 1,
                    data: Some(Vec::new()),
                },
                Block {
                    index: 0,
                    length: 1,
                    data: Some(Vec::new()),
                },
                Block {
                    index: 0,
                    length: 1,
                    data: None,
                },
                Block {
                    index: 0,
                    length: 1,
                    data: Some(Vec::new()),
                },
            ],
            hash: vec![],
            is_complete: false,
        };
        assert_eq!(false, p3.have_all_blocks());
    }

    #[test]
    fn next_block_test() {
        let p = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![
                Block {
                    index: 0,
                    length: 1,
                    data: Some(Vec::new()),
                },
                Block {
                    index: 1,
                    length: 1,
                    data: Some(Vec::new()),
                },
                Block {
                    index: 2,
                    length: 1,
                    data: None,
                },
                Block {
                    index: 3,
                    length: 1,
                    data: Some(Vec::new()),
                },
            ],
            hash: vec![],
            is_complete: false,
        };
        assert_eq!(
            &Block {
                index: 2,
                length: 1,
                data: None
            },
            p.next_block_to_request().unwrap()
        );
        let p2 = Piece {
            length: 0,
            piece_length: 0,
            index: 0,
            blocks: vec![Block {
                index: 0,
                length: 1,
                data: Some(Vec::new()),
            }],
            hash: vec![],
            is_complete: false,
        };
        assert!(p2.next_block_to_request().is_none());
    }
}
