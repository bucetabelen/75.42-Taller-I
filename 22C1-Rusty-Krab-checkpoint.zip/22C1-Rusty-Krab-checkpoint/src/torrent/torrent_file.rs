use super::metainfo::MetaInfo;
use crate::torrent::piece::Piece;
use crate::utils::error::TorrentError;
use std::fs::{self, File, OpenOptions};
use std::path::Path;

#[derive(Debug)]
pub struct Torrent {
    pub metainfo: MetaInfo,
    pub peer_id: String,
    pub file: File,
    pub file_path: String,
    pub pieces: Vec<Piece>,
}

/// Represents the entire torrent, including metainfo derived from the `.torrent` file as well as
/// the client's id, the file to be downloaded and the pieces of the file
impl Torrent {
    pub fn new(
        peer_id: &str,
        metainfo: MetaInfo,
        download_path: String,
    ) -> Result<Self, TorrentError> {
        println!("Creating torrent...\n");
        let piece_length = metainfo.info.piece_length;
        let num_pieces = metainfo.info.num_pieces;

        let filename = metainfo.clone().info.name;
        let file_path = format!("{}/{}", download_path, filename);

        let path = Path::new(&file_path);

        //to create the directory (if it doesn't exist yet) where we want to write the file.
        if !Path::new(&download_path).exists() {
            let download_path_error = download_path.clone();
            match fs::create_dir(download_path) {
                Ok(_) => {}
                Err(_) => {
                    return Err(TorrentError::DownloadPathError(download_path_error));
                }
            }
        }

        // to create the file (if it doesn't exist yet) we want to write
        if !path.exists() {
            match File::create(path) {
                Ok(f) => {
                    let _ = f.set_len(metainfo.info.files[0].length as u64);
                }
                Err(_) => {
                    let path_error = filename;
                    return Err(TorrentError::DownloadPathError(path_error));
                }
            }
        }

        let file = OpenOptions::new().write(true).open(path)?;

        let mut pieces: Vec<Piece> = vec![];
        let n = metainfo.info.pieces.len();

        for i in 0..n {
            let length = {
                if i == n - 1 {
                    num_pieces % piece_length
                } else {
                    piece_length
                }
            };

            let piece = Piece::new(
                length,
                i as u32,
                piece_length,
                metainfo.info.pieces[i as usize].clone(),
            );
            pieces.push(piece);
        }
        println!("Torrent created!\n");

        Ok(Torrent {
            metainfo,
            peer_id: peer_id.to_string(),
            file,
            file_path,
            pieces,
        })
    }

    /// obtain the next block for the request, indicating the index of the block piece and its size,
    /// in case all the blocks are complete it will return None
    pub fn next_block_to_request(&self, peer_has_pieces: &[bool]) -> Option<(u32, u32, u32)> {
        for piece in self.pieces.iter() {
            if peer_has_pieces[piece.index as usize] {
                if let Some(block) = piece.next_block_to_request() {
                    return Some((piece.index, block.index, block.length));
                }
            }
        }
        None
    }

    /// Given a piece index, block index, a vector of bytes for a block, we store
    /// the new block at its position within the piece and return whether or not
    /// the piece is complete to determine if we should keep requesting blocks
    pub fn store(
        &mut self,
        piece_index: u32,
        block_index: u32,
        data: Vec<u8>,
    ) -> Result<bool, TorrentError> {
        let piece = &mut self.pieces[piece_index as usize];
        (piece.store(&mut self.file, block_index, data))?;

        Ok(self.is_complete())
    }

    /// Returns a boolean that represents whether all the pieces for the
    /// torrent has been retrieved
    fn is_complete(&self) -> bool {
        for piece in self.pieces.iter() {
            if piece.is_complete {
                return true;
            }
        }
        false
    }
}

impl PartialEq for Torrent {
    fn eq(&self, other: &Torrent) -> bool {
        self.metainfo == other.metainfo
            && self.peer_id == other.peer_id
            && self.pieces == other.pieces
    }
}

#[cfg(test)]
mod tests {
    use std::fs::{self, File};
    use std::path::Path;

    use super::Torrent;
    use crate::configuration::client_configuration::Configuration;
    use crate::torrent::block::Block;
    use crate::torrent::metainfo::{Info, MetaInfo};
    use crate::torrent::piece::Piece;

    use crate::torrent::metainfo::FileInfo;
    use crate::utils::methods::create_peer_id;

    #[test]
    fn test_torrent_creation() {
        let filename = String::from("test_files/info.txt");

        let f_i = FileInfo {
            length: 654564564,
            path: Some(filename.clone()),
        };
        let i = Info {
            piece_length: 12,
            pieces: vec![vec![1, 2, 3]],
            num_pieces: 3,
            multiple_file: false,
            name: String::from("info.txt"),
            files: vec![f_i],
        };

        let m = MetaInfo {
            announce: String::from("https://google.com/announce"),
            created_by: Some(String::from("tov")),
            comment: Some(String::from("some comment")),
            creation_date: Some(465465),
            encoding: Some(String::from("some encoding")),
            info: i,
            info_hash: vec![2, 3, 4],
        };

        let path = Path::new(&filename);
        let _ = File::create(path);
        let f = File::open(path).unwrap();
        let peer_id = create_peer_id();

        let configuration = Configuration::new(
            "80".parse::<usize>().unwrap(),
            "test_files".to_string(),
            "test_files".to_string(),
        );

        let t = Torrent::new(&peer_id, m.clone(), configuration.download_path);
        match t {
            Ok(torrent) => {
                assert_eq!(
                    torrent,
                    Torrent {
                        metainfo: m,
                        peer_id: peer_id,
                        file: f,
                        file_path: "test_files/info.txt".to_string(),
                        pieces: vec![Piece {
                            length: 3,
                            index: 0,
                            piece_length: 12,
                            blocks: vec![Block::new(0, 3)],
                            hash: vec![1, 2, 3],
                            is_complete: false,
                        }],
                    }
                )
            }
            Err(_) => assert!(false),
        };

        let _ = fs::remove_file(path);
    }
}
