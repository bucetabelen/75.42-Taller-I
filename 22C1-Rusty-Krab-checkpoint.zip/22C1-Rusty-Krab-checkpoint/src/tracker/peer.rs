use crate::utils::error::TorrentError;
use std::net::Ipv4Addr;

#[derive(Debug, Clone, PartialEq)]
pub struct Peer {
    pub peer_id: String,
    pub port: usize,
    pub ip: Ipv4Addr,
    pub have: Vec<bool>,
    pub choked: Option<bool>,
    pub interested: Option<bool>,
}

/// Represents a peer from which a client can request data
impl Peer {
    pub fn new(v: &[u8]) -> Self {
        let ip = Ipv4Addr::new(v[0], v[1], v[2], v[3]);

        let port = u16::from_ne_bytes([v[5], v[4]]);
        Peer {
            ip,
            port: port as usize,
            peer_id: "no id".to_string(),
            have: vec![],
            choked: None,
            interested: None,
        }
    }

    /// given an ip and the name of a peer, return a peer

    pub fn new_with_peer_id(
        port: usize,
        ip: String,
        peer_id: String,
    ) -> Result<Self, TorrentError> {
        let ip = ip.parse::<Ipv4Addr>()?;
        Ok(Peer {
            ip,
            port,
            peer_id,
            have: vec![],
            choked: None,
            interested: None,
        })
    }

    /// register a piece, in case the "choke" and "interest" fields have not been completed,
    /// they will be set to false

    pub fn register(&mut self, pieces: usize) {
        self.have = vec![false; pieces];

        if self.choked == None {
            self.choked = Some(false)
        }

        if self.interested == None {
            self.interested = Some(false)
        }
    }
}

#[cfg(test)]
mod peer_tests {
    use super::Peer;
    use std::net::Ipv4Addr;
    #[test]
    fn test_peer_new() {
        let bytes = [127, 0, 0, 1, 31, 144];
        let p = Peer::new(&bytes);
        assert_eq!(
            p,
            Peer {
                ip: Ipv4Addr::new(127, 0, 0, 1),
                port: 8080,
                peer_id: "no id".to_string(),
                have: vec![],
                choked: None,
                interested: None,
            }
        )
    }

    #[test]
    fn test_register() {
        let mut p = Peer {
            peer_id: "".to_string(),
            port: 0,
            ip: Ipv4Addr::new(127, 0, 0, 1),
            have: vec![],
            choked: None,
            interested: None,
        };
        p.register(2);
        assert_eq!(
            Peer {
                peer_id: "".to_string(),
                port: 0,
                ip: Ipv4Addr::new(127, 0, 0, 1),
                have: vec![false, false],
                choked: Some(false),
                interested: Some(false)
            },
            p
        )
    }
}
