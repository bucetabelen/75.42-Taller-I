//! MessageHandshake
//!
//! Represents the message to initiates or receives the handshake with peers.

const PROTOCOL_LEN: u32 = 19;
const HASH_PEERID_LEN: u32 = 20;
pub const PROTOCOL: &str = "BitTorrent protocol";

use std::str::from_utf8;

use crate::utils::error::{MessageError, TorrentError};

/// Message Handshake
///
/// - protocol: Usually `BitTorrent protocol`
/// - info_hash: The info hash to send or received
/// - peer_id: The peer id to send or received
pub struct MessageHandshake {
    pub protocol: String,
    pub info_hash: Vec<u8>,
    pub peer_id: Vec<u8>,
}

impl MessageHandshake {
    /// MessageHandshak constructor.
    ///
    /// Receives the protocol, info_hash and peer_id.
    ///
    /// Returns a MessageHandshake.
    ///
    /// # Errors
    ///
    /// This function will return an error depending on:
    /// - The protocol is not equal to "BitTorrent protocol"
    /// - The message doesn't have the length expected
    ///
    /// # Example
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message_handshake::MessageHandshake;
    ///
    /// let info_hash: &[u8] = &[
    /// 44, 107, 104, 88, 214, 29, 169, 84, 61, 66, 49, 167, 29, 180, 177, 201, 38, 75, 6, 133,
    /// ];
    /// let peer_id: &[u8] = &[
    ///     45, 108, 116, 48, 68, 56, 48, 45, 33, 197, 141, 160, 226, 49, 157, 151, 64, 247, 144,
    ///    177,
    /// ];
    ///
    /// let message = MessageHandshake::new("BitTorrent protocol".to_string(), info_hash, peer_id).unwrap();
    ///
    /// // Now we have a MessageHandshake
    /// ```
    pub fn new(
        protocol: String,
        info_hash: &[u8],
        peer_id: &[u8],
    ) -> Result<MessageHandshake, TorrentError> {
        if protocol.len() as u32 != PROTOCOL_LEN
            || info_hash.len() as u32 != HASH_PEERID_LEN
            || peer_id.len() as u32 != HASH_PEERID_LEN
        {
            return Err(TorrentError::MessageError(MessageError::InvalidLength));
        }

        if protocol != PROTOCOL {
            return Err(TorrentError::MessageError(MessageError::InvalidProtocol));
        }

        Ok(MessageHandshake {
            protocol,
            info_hash: info_hash.to_vec(),
            peer_id: peer_id.to_vec(),
        })
    }

    /// Similar to MessageWritter in messages p2p, the write function parses the MessageHandshake to `Vec<u8>` to send to a peer.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message_handshake::MessageHandshake;
    ///
    /// let info_hash: &[u8] = &[
    /// 44, 107, 104, 88, 214, 29, 169, 84, 61, 66, 49, 167, 29, 180, 177, 201, 38, 75, 6, 133,
    /// ];
    /// let peer_id: &[u8] = &[
    ///     45, 84, 82, 51, 48, 48, 48, 45, 105, 120, 53, 108, 52, 102, 55, 48, 48, 100, 106, 57,
    /// ];
    /// let protocol = "BitTorrent protocol".to_string();
    /// let protocol_as_bytes = protocol.as_bytes();
    ///
    /// let mut expected_message: Vec<u8> = vec![19 as u8];
    /// expected_message.extend(protocol_as_bytes.into_iter());
    /// expected_message.extend(vec![0; 8].into_iter());
    /// expected_message.extend(info_hash.into_iter());
    /// expected_message.extend(peer_id.into_iter());
    ///
    /// let message = MessageHandshake::new(protocol, info_hash, peer_id).unwrap();
    /// let message_writed = MessageHandshake::write(message).unwrap();
    ///
    /// assert_eq!(message_writed, expected_message);
    /// ```
    pub fn write(message: MessageHandshake) -> Result<Vec<u8>, TorrentError> {
        let mut result = vec![message.protocol.len() as u8];
        result.extend(message.protocol.bytes());
        // Reserved 8 bytes
        result.extend(vec![0; 8].iter());
        result.extend(message.info_hash.iter());
        result.extend(message.peer_id.iter());
        Ok(result)
    }

    /// Reads from `&[u8]` and parses the message to MessageHandshake
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use rusty_krab_torrent::tracker::messages::message_handshake::MessageHandshake;
    ///
    /// let protocol_expected = "BitTorrent protocol";
    /// let mut message_handshake = vec![];
    /// message_handshake.push(protocol_expected.len() as u8);
    /// message_handshake.extend(protocol_expected.as_bytes());
    /// message_handshake.extend(vec![0; 8].into_iter());
    ///
    /// let info_hash_expected: &[u8] = &[
    ///     44, 107, 104, 88, 214, 29, 169, 84, 61, 66, 49, 167, 29, 180, 177, 201, 38, 75, 6, 133,
    /// ];
    /// let peer_id_expected: &[u8] = &[
    ///     45, 108, 116, 48, 68, 56, 48, 45, 33, 197, 141, 160, 226, 49, 157, 151, 64, 247, 144,
    ///     177,
    /// ];
    /// message_handshake.extend(info_hash_expected.into_iter());
    /// message_handshake.extend(peer_id_expected.into_iter());
    ///
    /// let message_readed = MessageHandshake::read(&message_handshake).unwrap();
    /// assert_eq!(protocol_expected, message_readed.protocol);
    /// assert_eq!(info_hash_expected.to_vec(), message_readed.info_hash);
    /// assert_eq!(peer_id_expected.to_vec(), message_readed.peer_id);
    /// ```
    pub fn read(message: &[u8]) -> Result<MessageHandshake, TorrentError> {
        if message.len() < 68 {
            return Err(TorrentError::MessageError(MessageError::InvalidLength));
        }

        match from_utf8(&message[1..20]) {
            Ok(protocol) => {
                MessageHandshake::new(protocol.to_string(), &message[28..48], &message[48..68])
            }
            Err(_) => Err(TorrentError::MessageError(MessageError::InvalidProtocol)),
        }
    }
}

#[cfg(test)]
mod tests {
    use crate::tracker::messages::message_handshake::*;

    #[test]
    fn write_message_handshake_test() {
        let info_hash: &[u8] = &[
            44, 107, 104, 88, 214, 29, 169, 84, 61, 66, 49, 167, 29, 180, 177, 201, 38, 75, 6, 133,
        ];
        let peer_id: &[u8] = &[
            45, 84, 82, 51, 48, 48, 48, 45, 105, 120, 53, 108, 52, 102, 55, 48, 48, 100, 106, 57,
        ];
        let protocol = "BitTorrent protocol".to_string();
        let protocol_as_bytes = protocol.as_bytes();
        let mut expected_message: Vec<u8> = vec![19 as u8];
        expected_message.extend(protocol_as_bytes.into_iter());
        expected_message.extend(vec![0; 8].into_iter());
        expected_message.extend(info_hash.into_iter());
        expected_message.extend(peer_id.into_iter());
        let message = MessageHandshake::new(protocol, info_hash, peer_id).unwrap();

        match MessageHandshake::write(message) {
            Ok(message_writed) => assert_eq!(expected_message, message_writed),
            Err(_) => assert!(false),
        }
    }

    #[test]
    fn read_handshake_test() {
        let protocol_expected = "BitTorrent protocol";
        let mut message_handshake = vec![];
        message_handshake.push(protocol_expected.len() as u8);
        message_handshake.extend(protocol_expected.as_bytes());
        message_handshake.extend(vec![0; 8].into_iter());

        let info_hash_expected: &[u8] = &[
            44, 107, 104, 88, 214, 29, 169, 84, 61, 66, 49, 167, 29, 180, 177, 201, 38, 75, 6, 133,
        ];
        let peer_id_expected: &[u8] = &[
            45, 108, 116, 48, 68, 56, 48, 45, 33, 197, 141, 160, 226, 49, 157, 151, 64, 247, 144,
            177,
        ];
        message_handshake.extend(info_hash_expected.into_iter());
        message_handshake.extend(peer_id_expected.into_iter());

        match MessageHandshake::read(&message_handshake) {
            Ok(message) => {
                assert_eq!(protocol_expected, message.protocol);
                assert_eq!(info_hash_expected.to_vec(), message.info_hash);
                assert_eq!(peer_id_expected.to_vec(), message.peer_id);
            }
            Err(_) => assert!(false),
        }
    }
}
