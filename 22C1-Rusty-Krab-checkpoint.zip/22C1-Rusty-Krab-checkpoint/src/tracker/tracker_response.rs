use crate::bencode::bencode_type::FromBencodeType;

use crate::bencode::decoder::Decoder;
use crate::torrent::metainfo::MetaInfo;
use crate::utils::error::TorrentError;
use crate::utils::methods::{get_domain, get_url_encode, parameterize, remove_header};
use native_tls::TlsConnector;
use std::io::{Read, Write};
use std::net::TcpStream;
use std::vec;

use super::peer::Peer;

pub const TRACKER_PORT: &str = "443";
pub const HTTP: &str = "http:";
pub const HTTPS: &str = "https:";
pub const ANNOUNCE: &str = "announce";
pub const EMPTY: &str = "";
pub const END_OF_CONNECTION: &str = "Connection:close";
pub const LINE_SEPARATOR: char = '\n';
pub const SPACE_SEPARATOR: char = ' ';
pub const RETURN: char = '\r';

#[derive(Debug, Clone)]
pub struct TrackerHandshake {
    pub incomplete: usize,
    pub complete: usize,
    pub interval: usize,
    pub peers: Vec<Peer>,
}

/// Sends a request to the tracker specified by the MetaInfo's announce attribute and
/// returns the response of the tracker in bytes.

pub fn connect_to_tracker(
    metainfo: &MetaInfo,
    peer_id: &str,
    port: &str,
) -> Result<Vec<u8>, TorrentError> {
    let uploaded = String::from("0");
    let downloaded = String::from("0");
    let left = metainfo.info.files[0].length.to_string(); // retrieves length of first file for now
    let url = get_url_encode(&metainfo.info_hash);

    let peer_url = get_url_encode(peer_id.as_bytes());
    let compact = String::from("1");

    let params: Vec<(&str, &str)> = vec![
        ("info_hash", url.as_ref()),
        ("peer_id", peer_url.as_ref()),
        ("port", port),
        ("uploaded", uploaded.as_ref()),
        ("downloaded", downloaded.as_ref()),
        ("left", left.as_ref()),
        ("compact", compact.as_ref()),
        ("event", "started"),
    ];

    let query_params = parameterize(params);

    let (domain, port) = get_domain(&metainfo.announce);

    let tracker_address = match port {
        Some(_port) => format!("{}:{}", domain, 80),
        None => format!("{}:{}", domain, TRACKER_PORT),
    };

    // Case Https/Http
    match metainfo.announce.contains(HTTPS) {
        true => https_request(tracker_address, domain, query_params),
        false => http_request(tracker_address, domain, query_params),
    }
}

/// announces a url with the address of the tracker and parameters given to the domain (also given),
/// returns what they answer
///
/// Use for https requests to tracker
pub fn https_request(
    tracker_address: String,
    domain: &str,
    query_params: String,
) -> Result<Vec<u8>, TorrentError> {
    let query_url = format!("https://{}/announce?{}", tracker_address, query_params);

    let connector = TlsConnector::builder().build()?;

    let tcp_stream = TcpStream::connect(&tracker_address)?;

    let mut tls = connector.connect(domain, tcp_stream)?;
    println!("\tConnection established! \n");

    let get_query = format!("GET {} HTTP/1.0\r\n\r\n", query_url);

    println!(" Sending query... {}\n", get_query);

    tls.write_all(get_query.as_bytes()).unwrap();

    let mut res = vec![];

    tls.read_to_end(&mut res).unwrap();

    Ok(res)
}

/// announces a url with the address of the tracker and parameters given to the domain (also given),
/// returns what they answer
///
/// Use for http requests to tracker

pub fn http_request(
    tracker_address: String,
    domain: &str,
    query_params: String,
) -> Result<Vec<u8>, TorrentError> {
    let query_url = format!("/announce?{}", query_params);

    let mut tcp_stream = TcpStream::connect(&tracker_address)?;

    let get_query = format!("GET {} HTTP/1.0\r\nHost:{}\r\n", query_url, domain);

    println!("\tSending query... {}\n", get_query);

    tcp_stream.write_all(get_query.as_bytes()).unwrap();

    let mut res = vec![];

    tcp_stream.read_to_end(&mut res).unwrap();

    Ok(res)
}

// Connects to the tracker and returns a TrackerHandshake.
pub fn retrieve_peers(
    metainfo: &MetaInfo,
    client: &Peer,
) -> Result<TrackerHandshake, TorrentError> {
    println!("Making request to tracker...\n");

    let client_peer_id = &client.peer_id;
    let mut response_bytes =
        connect_to_tracker(metainfo, client_peer_id, &client.port.to_string())?;
    let response = remove_header(&mut response_bytes);

    println!("\tRetrieving peers...\n");
    let bencode = Decoder::decode(&response)?;

    let handshake = TrackerHandshake::from_bencode_type(&bencode);
    println!("\tPeers retrieved!\n");
    handshake
}

#[cfg(test)]
mod tests {
    use super::parameterize;
    use super::retrieve_peers;
    use super::TrackerHandshake;
    use crate::bencode::bencode_type::FromBencodeType;
    use crate::bencode::decoder::Decoder;
    use crate::tracker::peer::Peer;
    use crate::{torrent::metainfo::MetaInfo, utils::methods::create_peer_id};

    const TEST_TORRENT_FILE: &str = "test_files/ubuntu-22.04-desktop-amd64.iso.torrent";
    const LOCALHOST: &str = "127.0.0.1";

    #[test]
    pub fn test_tracker() {
        let metainfo = MetaInfo::read(TEST_TORRENT_FILE);
        match metainfo {
            Ok(metainfo) => {
                let peer_id = create_peer_id();
                let client = Peer::new_with_peer_id(
                    "80".parse::<usize>().unwrap(),
                    LOCALHOST.to_string(),
                    peer_id,
                )
                .unwrap();
                match retrieve_peers(&metainfo, &client) {
                    Ok(_) => println!("Connection Ended"),
                    Err(e) => println!("{:?}", e),
                }
            }
            Err(e) => println!("{:?}", e),
        }
    }

    #[test]
    fn sample_params_test() {
        let params: Vec<(&str, &str)> = vec![("peer_id", "l33t"), ("port", "8080")];
        assert_eq!("peer_id=l33t&port=8080".to_string(), parameterize(params));
    }

    #[test]
    fn test_tracker_response() {
        let s = vec![
            100, 56, 58, 99, 111, 109, 112, 108, 101, 116, 101, 105, 49, 101, 49, 48, 58, 100, 111,
            119, 110, 108, 111, 97, 100, 101, 100, 105, 51, 101, 49, 48, 58, 105, 110, 99, 111,
            109, 112, 108, 101, 116, 101, 105, 50, 101, 56, 58, 105, 110, 116, 101, 114, 118, 97,
            108, 105, 49, 56, 51, 56, 101, 49, 50, 58, 109, 105, 110, 32, 105, 110, 116, 101, 114,
            118, 97, 108, 105, 57, 49, 57, 101, 53, 58, 112, 101, 101, 114, 115, 49, 56, 58, 98,
            227, 182, 253, 31, 144, 165, 124, 144, 88, 31, 144, 96, 126, 104, 219, 238, 9, 101,
        ];

        let bencode = Decoder::decode(&s).unwrap();
        let decoded = TrackerHandshake::from_bencode_type(&bencode);
        match decoded {
            Ok(response) => {
                assert_eq!(response.interval, 1838);
                assert_eq!(response.complete, 1);
                assert_eq!(response.incomplete, 2);
                assert_eq!(
                    response.peers,
                    vec![
                        Peer::new(&[98, 227, 182, 253, 31, 144]),
                        Peer::new(&[165, 124, 144, 88, 31, 144]),
                        Peer::new(&[96, 126, 104, 219, 238, 9]),
                    ]
                );
            }
            _ => panic!("Decoded bencode incorrectly"),
        }
    }
}
