use super::messages::message_handshake::{MessageHandshake, PROTOCOL};
use super::peer::Peer;
use crate::torrent::piece::BLOCK_SIZE;
use crate::torrent::torrent_file::Torrent;
use crate::tracker::messages::message::Message;
use crate::tracker::messages::message_reader::MessageReader;
use crate::tracker::messages::message_writer::MessageWriter;
use crate::utils::error::{MessageError, PeerConnectionError, TorrentError};
use crate::utils::methods::parse_vec_u8_into_u32;
use std::io::{Read, Write};
use std::net::IpAddr;
use std::net::SocketAddr;
use std::net::TcpStream;

pub struct PeerConnection<'a> {
    tcp_stream: TcpStream,
    peer: Peer,
    client: &'a mut Peer,
    torrent: &'a mut Torrent,
}

pub enum IpcMessage {
    CancelRequest(u32, u32),
}

impl PeerConnection<'_> {
    pub fn new<'a>(
        client: &'a mut Peer,
        mut peer: Peer,
        stream: TcpStream,
        torrent: &'a mut Torrent,
    ) -> PeerConnection<'a> {
        let num_pieces = torrent.pieces.len();
        client.register(num_pieces);
        peer.register(num_pieces);

        PeerConnection {
            tcp_stream: stream,
            client,
            peer,
            torrent,
        }
    }

    /// given the peers for the connection and the torrent
    /// initiate connection to peer using handshake
    /// tcp connection may fail
    /// handshake can fail
    pub fn connect_to_peer(
        peer_to_connect: Peer,
        client: &mut Peer,
        torrent: &mut Torrent,
    ) -> Result<(), TorrentError> {
        println!(
            "Connecting to peer {} - {}:{}\n",
            peer_to_connect.peer_id, peer_to_connect.ip, peer_to_connect.port
        );

        let socket = SocketAddr::new(IpAddr::V4(peer_to_connect.ip), peer_to_connect.port as u16);

        match TcpStream::connect(&socket) {
            Ok(tcp_stream) => {
                println!("\tConnected succesfully!\n");

                let mut connection =
                    PeerConnection::new(client, peer_to_connect, tcp_stream, torrent);
                match connection.peers_handshaking() {
                    Ok(()) => {
                        let mut done = false;
                        while !done {
                            let message = connection.receive_message()?;
                            println!("\tMessage received: {}\n", &message);
                            done = connection.handle_message(message)?;
                        }
                        Ok(())
                    }
                    Err(error) => Err(error),
                }
            }
            Err(_) => Err(TorrentError::PeerConnectionError(
                PeerConnectionError::BadConnection,
            )),
        }
    }

    /// receive messages from the connection with a peer
    /// the connection may fail
    /// reading the message may fail
    pub fn receive_message(&mut self) -> Result<Message, TorrentError> {
        match PeerConnection::read_stream(&self.tcp_stream, 4) {
            Ok(buf_length) => {
                let length = parse_vec_u8_into_u32(&buf_length);
                match PeerConnection::read_stream(&self.tcp_stream, length) {
                    Ok(buf_message) => MessageReader::read(&buf_message),
                    Err(error) => Err(error),
                }
            }
            Err(error) => Err(error),
        }
    }

    /// Given a message, it sends it down the connection to the other peer.
    /// the connection may fail
    /// sending the message may fail
    pub fn send_message(&mut self, message: Message) -> Result<(), TorrentError> {
        println!("\tSending message...{}\n", &message);

        match MessageWriter::write(message) {
            Ok(message_fmt) => match self.tcp_stream.write_all(&message_fmt) {
                Ok(_) => {
                    println!("\tMessage sent!\n");
                    Ok(())
                }
                Err(_) => Err(TorrentError::PeerConnectionError(
                    PeerConnectionError::ErrorSendingMessage,
                )),
            },
            Err(error) => Err(error),
        }
    }

    /// given the connection and the size of a receive buffer loads the buffer with the messages and returns them
    /// the connection may fail
    /// sending the message may fail
    fn read_stream(tcp_stream: &TcpStream, bytes: u32) -> Result<Vec<u8>, TorrentError> {
        let mut buf: Vec<u8> = Vec::new();
        let mut stream_take = (tcp_stream).take(bytes as u64);

        match stream_take.read_to_end(&mut buf) {
            Ok(length) => {
                if length == bytes as usize {
                    Ok(buf)
                } else {
                    Err(TorrentError::MessageError(MessageError::InvalidLength))
                }
            }
            _ => Err(TorrentError::PeerConnectionError(
                PeerConnectionError::ErrorReadingResponse,
            )),
        }
    }

    /// start the handshake and wait for the confirmation of this
    /// both handshake initiation and handshake confirmation may fail
    pub fn peers_handshaking(&mut self) -> Result<(), TorrentError> {
        match self.initialize_handshake() {
            Ok(()) => match self.receive_handshake_response() {
                Ok(()) => Ok(()),
                Err(error) => Err(error),
            },
            Err(error) => Err(error),
        }
    }

    /// configure and start handshake transmission
    fn initialize_handshake(&mut self) -> Result<(), TorrentError> {
        let client_peer_id = self.client.peer_id.as_bytes();
        match MessageHandshake::new(
            PROTOCOL.to_string(),
            &self.torrent.metainfo.info_hash,
            client_peer_id,
        ) {
            Ok(message) => match MessageHandshake::write(message) {
                Ok(message) => match self.tcp_stream.write_all(&message) {
                    Ok(_) => println!("\tHandshake sent!\n"),
                    Err(_) => {
                        return Err(TorrentError::PeerConnectionError(
                            PeerConnectionError::ErrorSendingHandshake,
                        ))
                    }
                },
                Err(error) => return Err(error),
            },
            Err(error) => return Err(error),
        }
        Ok(())
    }

    /// receives the response from the handshake and verifies the data,
    /// it can fail due to lack of data, erroneous data or connection failure to receive the message
    fn receive_handshake_response(&mut self) -> Result<(), TorrentError> {
        match PeerConnection::read_stream(&self.tcp_stream, 68) {
            Ok(response) => {
                if response.is_empty() {
                    return Err(TorrentError::PeerConnectionError(
                        PeerConnectionError::BadResponse,
                    ));
                }
                match MessageHandshake::read(&response) {
                    Ok(message) => {
                        // Debug
                        println!(
                            "\tSuccesfull handshake!\n\tProtocol: {:?}\n\tInfo_hash: {:?}\n\tPeer_id: {:?}\n",
                            message.protocol, message.info_hash, message.peer_id
                        );
                    }
                    Err(error) => return Err(error),
                }
                Ok(())
            }
            Err(error) => Err(error),
        }
    }

    /// given a type of message it generates and sends it

    fn handle_message(&mut self, message: Message) -> Result<bool, TorrentError> {
        match message {
            Message::KeepAlive => {}
            Message::Bitfield { bitfield: bytes } => {
                let num_pieces = self.client.have.len();
                let mut peer_have = self.peer.have.clone();
                for (i, item) in peer_have.iter_mut().enumerate().take(num_pieces) {
                    let bytes_index = i / 8;
                    let index_into_byte = i % 8;
                    let byte = bytes[bytes_index];
                    let value = (byte & (1 << (7 - index_into_byte))) != 0;
                    *item = value;
                }
                self.peer.have = peer_have;

                let _ = self.send_message(Message::Interested);
            }
            Message::Have {
                piece_index: have_index,
            } => {
                self.client.have[have_index as usize] = true;

                let _ = self.send_message(Message::Interested);
            }

            Message::Unchoke => {
                self.client.choked = Some(false);

                let _ = self.request_next_block();
            }
            Message::Piece {
                index: piece_index,
                begin: offset,
                block: data,
            } => {
                let is_complete = {
                    let block_index = offset / (BLOCK_SIZE as u32);
                    self.torrent.store(piece_index, block_index, data)?
                };

                if is_complete {
                    return Ok(true);
                } else {
                    let _ = self.request_next_block();
                }
            }
            Message::Cancel {
                index: _,
                begin: _,
                length: _,
            } => {
                let _ = self.request_next_block();
            }
            _ => panic!("\tNeed to process message: {:?}\n", message),
        };
        Ok(false)
    }

    ///it looks for the next block to download and sends the message that it is looking for that
    /// block, if there are no more blocks to download it does not send any message
    fn request_next_block(&mut self) -> Result<(), TorrentError> {
        let next_block = self.torrent.next_block_to_request(&self.peer.clone().have);

        match next_block {
            Some((piece_index, block_index, block_length)) => {
                let offset = block_index * BLOCK_SIZE as u32;
                self.send_message(Message::Request {
                    index: piece_index,
                    begin: offset,
                    length: block_length,
                })
            }
            None => {
                println!("We've downloaded all the pieces we can from this peer!\n");
                Ok(())
            }
        }
    }
}
