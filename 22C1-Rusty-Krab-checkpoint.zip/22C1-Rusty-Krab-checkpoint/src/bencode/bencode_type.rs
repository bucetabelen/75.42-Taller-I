// ! Types that could be encoded/decoded
// ! - String
// ! - Integer (usize)
// ! - List (Vec<BencodeType>)
// ! - Dictionary (HashMap<String, BencodeType>)

use crate::{
    torrent::{
        hash,
        metainfo::{FileInfo, Info, MetaInfo},
    },
    tracker::{peer::Peer, tracker_response::TrackerHandshake},
    utils::{
        error::{MetainfoError, TorrentError, TrackerError},
        methods::{get_info_dictionary, get_value},
    },
};
use std::collections::HashMap;

use super::encoder::Encoder;

/// BencodeType
///
/// enum with types that could be encoded/decoded
/// - String
/// - usize
/// - Vec<BencodeType>
/// - HashMap<String,BencodeType>
///
/// # Example
///
/// ```no_run

/// use rusty_krab_torrent::bencode::bencode_type::ToBencodeType;

///
/// let string: String = "a_string".to_string();
/// let string_bencode_type = string.to_bencode_type();
/// ```
/// Now string_bencode_type can be encoded to bencode.
/// See: rusty_krab_torrent::bencode::decode

#[derive(Debug, Clone)]

pub enum BencodeType {
    ByteString(ByteString),
    Integer(i64),
    List(Vec<BencodeType>),
    Dictionary(HashMap<String, BencodeType>),
}
#[derive(Debug, Clone)]
pub enum ByteString {
    Word(String),
    Pieces(Vec<u8>),
}

pub trait ToBencodeType {
    fn to_bencode_type(self) -> BencodeType;
}

impl ToBencodeType for usize {
    /// convert usize to BencodeType
    fn to_bencode_type(self) -> BencodeType {
        BencodeType::Integer(self.try_into().unwrap())
    }
}

impl ToBencodeType for String {
    /// convert String to BencodeType
    fn to_bencode_type(self) -> BencodeType {
        BencodeType::ByteString(ByteString::Word(self))
    }
}

impl ToBencodeType for &str {
    /// convert &str to BencodeType
    fn to_bencode_type(self) -> BencodeType {
        BencodeType::ByteString(ByteString::Word(self.to_string()))
    }
}

impl ToBencodeType for HashMap<String, BencodeType> {
    /// convert HashMap <String, BencodeType> to BencodeType
    fn to_bencode_type(self) -> BencodeType {
        BencodeType::Dictionary(self)
    }
}

impl ToBencodeType for Vec<BencodeType> {
    /// convert Vec<BencodeType> to BencodeType
    fn to_bencode_type(self) -> BencodeType {
        BencodeType::List(self)
    }
}

impl ToBencodeType for BencodeType {
    fn to_bencode_type(self) -> BencodeType {
        self
    }
}

impl ToBencodeType for Vec<u8> {
    fn to_bencode_type(self) -> BencodeType {
        BencodeType::ByteString(ByteString::Pieces(self))
    }
}

impl ToBencodeType for &[u8] {
    /// convert Vec<u8> to BencodeType
    fn to_bencode_type(self) -> BencodeType {
        BencodeType::ByteString(ByteString::Pieces(self.to_vec()))
    }
}

impl ToBencodeType for i32 {
    /// convert integer to BencodeType
    fn to_bencode_type(self) -> BencodeType {
        BencodeType::Integer((self).try_into().unwrap())
    }
}

impl ToBencodeType for i64 {
    /// convert integer to BencodeType
    fn to_bencode_type(self) -> BencodeType {
        BencodeType::Integer(self)
    }
}

impl PartialEq for BencodeType {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (BencodeType::List(list1), BencodeType::List(list2)) => list1 == list2,
            (BencodeType::Dictionary(hash1), BencodeType::Dictionary(hash2)) => hash1 == hash2,
            (BencodeType::Integer(int1), BencodeType::Integer(int2)) => int1 == int2,
            (
                BencodeType::ByteString(ByteString::Word(string1)),
                BencodeType::ByteString(ByteString::Word(string2)),
            ) => string1 == string2,
            (
                BencodeType::ByteString(ByteString::Pieces(pieces1)),
                BencodeType::ByteString(ByteString::Pieces(pieces2)),
            ) => pieces1 == pieces2,
            _ => false,
        }
    }
}

pub trait FromBencodeType: Clone {
    fn from_bencode_type(bencode_t: &BencodeType) -> Result<Self, TorrentError>
    where
        Self: Sized;
}

impl FromBencodeType for String {
    /// convert BencodeType to String
    fn from_bencode_type(bencode_t: &BencodeType) -> Result<String, TorrentError> {
        match *bencode_t {
            BencodeType::ByteString(ref string) => match string {
                ByteString::Word(string) => Ok(string.clone()),
                ByteString::Pieces(pieces) => {
                    let pieces_string = String::from_utf8_lossy(pieces);
                    Ok(pieces_string.as_ref().to_string())
                }
            },
            _ => Err(TorrentError::BencodeConversionError(
                "Attempted to convert non-string Bytestring to string".to_string(),
            )),
        }
    }
}

impl FromBencodeType for i64 {
    /// convert BencodeType to integer
    fn from_bencode_type(bencode_t: &BencodeType) -> Result<i64, TorrentError> {
        match *bencode_t {
            BencodeType::Integer(ref i) => Ok(*i as i64),
            _ => Err(TorrentError::BencodeConversionError(
                "Attempted to convert non-integer BencodeType to integer".to_string(),
            )),
        }
    }
}

impl FromBencodeType for usize {
    /// convert BencodeType to usize
    fn from_bencode_type(bencode_t: &BencodeType) -> Result<usize, TorrentError> {
        match *bencode_t {
            BencodeType::Integer(ref i) => Ok(*i as usize),
            _ => Err(TorrentError::BencodeConversionError(
                "Attempted to convert non-integer BencodeType to integer".to_string(),
            )),
        }
    }
}

impl FromBencodeType for Vec<u8> {
    /// convert BencodeType to vec<u8>
    fn from_bencode_type(bencode_t: &BencodeType) -> Result<Vec<u8>, TorrentError> {
        match *bencode_t {
            BencodeType::ByteString(ref string) => match string {
                ByteString::Word(_string) => Err(TorrentError::BencodeConversionError(
                    "Attempted to convert non-vecu8 BencodeType to vector".to_string(),
                )),

                ByteString::Pieces(pieces) => Ok(pieces.clone()),
            },
            _ => Err(TorrentError::BencodeConversionError(
                "Attempted to convert non-vecu8 BencodeType to vector".to_string(),
            )),
        }
    }
}

impl FromBencodeType for Vec<BencodeType> {
    /// convert BencodeType to vec<BencodeType>
    fn from_bencode_type(bencode_t: &BencodeType) -> Result<Vec<BencodeType>, TorrentError> {
        match bencode_t {
            &BencodeType::List(ref list) => Ok(list.clone()),
            _ => Err(TorrentError::BencodeConversionError(
                "Attempted to convert non-list BencodeType to vector".to_string(),
            )),
        }
    }
}

impl FromBencodeType for HashMap<String, BencodeType> {
    /// convert BencodeType to HashMap<String, BencodeType>
    fn from_bencode_type(
        bencode_t: &BencodeType,
    ) -> Result<HashMap<String, BencodeType>, TorrentError> {
        match bencode_t {
            &BencodeType::Dictionary(ref hm) => Ok(hm.clone()),
            _ => Err(TorrentError::BencodeConversionError(
                "Attempted to convert non-dictionary BencodeType to hashmap".to_string(),
            )),
        }
    }
}

impl FromBencodeType for Info {
    /// from_bencode_type for Info function creates the Info struct getting all the values from the info dictionary from the main BencodeType::Dictionary
    /// If the info element in the metainfo file is not represented as a dictionary, then it returns an error message.

    fn from_bencode_type(bencode_t: &BencodeType) -> Result<Info, TorrentError> {
        match bencode_t {
            &BencodeType::Dictionary(ref hm) => {
                let pieces = {
                    let vec = Vec::from_bencode_type(hm.get("pieces").unwrap())?;

                    Info::split_hashes(vec, 20)?
                };
                let num_pieces = pieces.len();
                Ok(Info {
                    piece_length: usize::from_bencode_type(hm.get("piece length").unwrap())?,
                    pieces,
                    num_pieces,
                    name: String::from_bencode_type(hm.get("name").unwrap())?,
                    multiple_file: {
                        match hm.get("files") {
                            Some(_bencode) => true,
                            None => false,
                        }
                    },
                    files: FileInfo::from_bencode_type(hm)?,
                })
            }

            _ => Err(TorrentError::BencodeConversionError(
                "Attempted to convert non-dictionary BencodeType to Info".to_string(),
            )),
        }
    }
}

impl FromBencodeType for MetaInfo {
    /// from_bencode_type for MetaInfo function creates the MetaInfo struct getting all the values from the main BencodeType::Dictionary
    /// If the announce element in the metainfo file is not present or the metainfo file is not formatted as Dictionary then it returns an error message.
    ///
    fn from_bencode_type(bencode: &BencodeType) -> Result<MetaInfo, TorrentError> {
        match bencode {
            &BencodeType::Dictionary(ref hm) => {
                let info_bytes = Encoder::encode(get_info_dictionary(hm, "info")?);

                let info_hash = hash::sha(&info_bytes);
                match get_value(hm, "announce") {
                    Some(announce) => Ok(MetaInfo {
                        info: Info::from_bencode_type(&get_info_dictionary(hm, "info")?)?,
                        announce,
                        creation_date: get_value(hm, "creation date"),
                        comment: get_value(hm, "comment"),
                        created_by: get_value(hm, "created by"),
                        encoding: get_value(hm, "encoding"),
                        info_hash,
                    }),
                    None => Err(TorrentError::MetainfoError(MetainfoError::AnnounceNotFound)),
                }
            }
            _ => Err(TorrentError::MetainfoError(MetainfoError::NotDictionary)),
        }
    }
}

impl FromBencodeType for TrackerHandshake {
    /// from_bencode_type for TrackerHandshake function creates the TrackerHandshake struct getting all the values from the main BencodeType::Dictionary.
    /// There are two possibilities regarding the format of the peers that we contemplate.
    /// Peers is a list of dictionaries or peers value is a string consisting of multiples of 6 bytes. First 4 bytes are the IP and
    /// last 2 bytes are the port number.
    /// The list of peers is length 50 by default.
    fn from_bencode_type(bencode: &BencodeType) -> Result<TrackerHandshake, TorrentError> {
        let mut peers_vec = Vec::<Peer>::new();
        match &bencode {
            &BencodeType::Dictionary(hm) => {
                match hm.get("peers") {
                    Some(peers) => match peers {
                        BencodeType::ByteString(ByteString::Pieces(list_of_peers)) => {
                            for i in 0..list_of_peers.len() / 6 {
                                let offset = i * 6;
                                let peer = Peer::new(&list_of_peers[offset..offset + 6]);
                                peers_vec.push(peer);
                            }
                        }
                        BencodeType::List(list_of_peers) => {
                            for dict in list_of_peers {
                                match dict {
                                    BencodeType::Dictionary(hm) => {
                                        let port = get_value(hm, "port").unwrap();
                                        let ip = get_value(hm, "ip").unwrap();
                                        let peer_id = get_value(hm, "peer id").unwrap();
                                        let peer = Peer::new_with_peer_id(port, ip, peer_id)?;
                                        peers_vec.push(peer);
                                    }
                                    _ => {
                                        return Err(TorrentError::MetainfoError(
                                            MetainfoError::NotDictionary,
                                        ))
                                    }
                                }
                            }
                        }
                        _ => {}
                    },
                    None => return Err(TorrentError::TrackerError(TrackerError::PeersNotFound)),
                }

                Ok(TrackerHandshake {
                    peers: peers_vec,
                    complete: get_value(hm, "complete").unwrap(),
                    incomplete: get_value(hm, "incomplete").unwrap(),
                    interval: get_value(hm, "interval").unwrap(),
                })
            }
            _ => Err(TorrentError::MetainfoError(MetainfoError::NotDictionary)),
        }
    }
}
