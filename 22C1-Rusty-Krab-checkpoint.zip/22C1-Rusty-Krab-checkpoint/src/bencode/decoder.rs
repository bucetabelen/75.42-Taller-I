// ! Bencode decoding
// !
// ! To decode a string encoded into BencodeType
// !
// ! Only works with u8 vec

use crate::utils::error::{DecoderError, TorrentError};

use super::bencode_type::*;
use std::collections::HashMap;

pub const STRING_POSTFIX: char = ':';
const POSTFIX: char = 'e';
const INTEGER_PREFIX: char = 'i';
const DICTIONARY_PREFIX: char = 'd';
const LIST_PREFIX: char = 'l';
const NEGATIVE_CHAR: char = '-';
const ZERO_CHAR: char = '0';

/// Decoder struct

pub struct Decoder;

impl Decoder {
    /// Decoder implementation
    ///
    /// This decoder only works with an u8 array (`&[u8]`).
    ///
    /// Decode function
    ///
    /// Returns a Result<BencodeType, TorrentError>, where BencodeType is the &[u8] decoded.
    ///
    /// # Errors
    ///
    /// This function will return an error if `encoded_bytes` has sintaxis errors (bad bencoding)
    ///
    /// # Examples
    /// ```
    /// use rusty_krab_torrent::bencode::decoder::Decoder;
    /// use rusty_krab_torrent::bencode::bencode_type::ToBencodeType;
    ///
    /// let string = "4:spam".as_bytes();
    /// match Decoder::decode(string) {
    ///     Ok(string_decoded) => assert_eq!("spam".to_bencode_type(), string_decoded),
    ///     Err(_) => assert!(false),
    /// }
    /// ```
    ///
    /// Note that "spam" is a BencodeType::ByteString, not String or `&[u8]`.
    pub fn decode(encoded_bytes: &[u8]) -> Result<BencodeType, TorrentError> {
        match Decoder::decode_element(encoded_bytes, 0) {
            Ok((a_bencode_type, _)) => Ok(a_bencode_type),
            Err(error) => Err(error),
        }
    }

    /// Decodes a BencodeType element.
    ///
    /// This function checks the `encoded_bytes[byte_index]` of encoded_bytes and calls a decode function.
    ///
    /// Returns the BencodeType decoded and the current byte_index.
    ///
    /// # Errors
    ///
    /// This function will return an error depending the decode function.
    fn decode_element(
        encoded_bytes: &[u8],
        byte_index: usize,
    ) -> Result<(BencodeType, usize), TorrentError> {
        if encoded_bytes.is_empty() {
            return Err(TorrentError::DecoderError(DecoderError::PostfixNotFound));
        }

        let first_byte = encoded_bytes[byte_index];
        let first_char = first_byte as char;

        match first_char as char {
            INTEGER_PREFIX => {
                // integer case
                Decoder::decode_integer(encoded_bytes, byte_index + 1)
            }
            DICTIONARY_PREFIX => {
                // dictionary key
                Decoder::decode_dictionary(encoded_bytes, byte_index + 1)
            }
            LIST_PREFIX => {
                // list case
                Decoder::decode_list(encoded_bytes, byte_index + 1)
            }
            '0'..='9' => Decoder::decode_string(encoded_bytes, byte_index),
            POSTFIX => {
                // postfix case
                Err(TorrentError::DecoderError(DecoderError::PostfixReached))
            }
            _ => Err(TorrentError::DecoderError(DecoderError::CharNotValid)),
        }
    }

    /// Finds the `final_char` and returns  till final_char position.
    ///
    /// Returns the substring obtained.
    ///
    /// # Errors
    ///
    /// This function will return an error if the postfix doesn't exists.
    fn find_and_drain_substring(
        bytes: &[u8],
        final_char: &char,
        len: usize,
    ) -> Result<(usize, usize), TorrentError> {
        let mut i = len;

        while (bytes[i] as char).is_digit(10) {
            i += 1;
        }

        if bytes[i] as char != *final_char {
            return Err(TorrentError::DecoderError(DecoderError::PostfixNotFound));
        }

        let len_string = std::str::from_utf8(&bytes[len..i])?;

        Ok((len_string.parse::<usize>().unwrap(), i))
    }

    /// This function parses the integer in bytes[len..] till the POSTFIX.
    ///
    /// Returns the updated byte_index and the integer parsed.
    ///
    /// `len` represents the current byte index.
    ///
    /// # Errors
    ///
    /// This function will return an error depending on:
    /// - Becoding rules
    /// - Parse integer error
    fn parse_int(bytes: &[u8], len: usize) -> Result<(i64, usize), TorrentError> {
        let mut i = len;

        loop {
            if i >= bytes.len() {
                return Err(TorrentError::DecoderError(
                    DecoderError::InvalidByteStringLength,
                ));
            }

            match bytes[i] as char {
                '0'..='9' => {
                    if len == i
                        // case "i0'n'e" where n is a number != 0
                        && (bytes[i] as char) == ZERO_CHAR
                        && (bytes[i + 1] as char).is_digit(10)
                    {
                        return Err(TorrentError::DecoderError(DecoderError::ParseIntegerError));
                    } else {
                        i += 1;
                    }
                }
                NEGATIVE_CHAR => {
                    if i != len {
                        // case NEGATIVE_CHAR is not first char
                        return Err(TorrentError::DecoderError(DecoderError::ParseIntegerError));
                    } else {
                        // case "i-0..e"/"i-e"
                        if (bytes[i + 1] as char) == POSTFIX || (bytes[i + 1] as char) == '0' {
                            return Err(TorrentError::DecoderError(
                                DecoderError::ParseIntegerError,
                            ));
                        }
                        i += 1;
                    }
                }
                POSTFIX => {
                    if i == len {
                        // case "ie"
                        return Err(TorrentError::DecoderError(DecoderError::ParseIntegerError));
                    }
                    break;
                }
                _ => {
                    return Err(TorrentError::DecoderError(DecoderError::ParseIntegerError));
                }
            }
        }

        let len_string = std::str::from_utf8(&bytes[len..i])?;
        Ok((len_string.parse::<i64>().unwrap(), i))
    }

    /// Decodes a dictionary
    ///
    /// Returns a BencodeType::Dictionary decoded and the updated byte_index in `&[u8]`.
    ///
    /// `i` represents the current byte index.
    ///
    /// # Errors
    ///
    /// This function will return an error if the postfix does not exist or a hash element has an error.
    fn decode_dictionary(
        encoded_bytes: &[u8],
        i: usize,
    ) -> Result<(BencodeType, usize), TorrentError> {
        let mut len = i;
        let mut hash: HashMap<String, BencodeType> = HashMap::new();

        loop {
            if len >= encoded_bytes.len() {
                return Err(TorrentError::DecoderError(
                    DecoderError::ByteStringLengthParseError,
                ));
            }

            match Decoder::decode_element(encoded_bytes, len) {
                Ok((key, len2)) => match key {
                    BencodeType::ByteString(ByteString::Word(key)) => {
                        match Decoder::decode_element(encoded_bytes, len2) {
                            Ok((value, new_len)) => {
                                len = new_len;
                                hash.insert(key, value);
                            }
                            Err(error) => return Err(error),
                        }
                    }
                    _ => {
                        return Err(TorrentError::DecoderError(DecoderError::DictKeyIsNotString));
                    }
                },
                Err(error) => match error {
                    TorrentError::DecoderError(DecoderError::PostfixReached) => {
                        return Ok((hash.to_bencode_type(), len + 1));
                    }
                    _ => return Err(TorrentError::DecoderError(DecoderError::PostfixNotFound)),
                },
            }
        }
    }

    /// Decodes a list
    ///
    /// Returns a BencodeType::List decoded and the updated byte index.
    ///
    /// `i` represents the current byte index.
    ///
    /// # Errors
    ///
    /// This function will return an error if the postfix does not exist or a list element has an error.
    fn decode_list(encoded_bytes: &[u8], i: usize) -> Result<(BencodeType, usize), TorrentError> {
        let mut list: Vec<BencodeType> = Vec::new();
        let mut len = i;
        loop {
            if len >= encoded_bytes.len() {
                return Err(TorrentError::DecoderError(
                    DecoderError::ByteStringLengthParseError,
                ));
            }

            match Decoder::decode_element(encoded_bytes, len) {
                Ok((element_to_push, new_len)) => {
                    len = new_len;
                    list.push(element_to_push);
                }
                Err(err) => match err {
                    TorrentError::DecoderError(DecoderError::PostfixReached) => {
                        return Ok((list.to_bencode_type(), len + 1));
                    }
                    _ => return Err(TorrentError::DecoderError(DecoderError::PostfixNotFound)),
                },
            }
        }
    }

    /// Decodes an integer
    ///
    /// Returns a BencodeType::Integer decoded and the updated byte_index.
    ///
    /// Argument `i` is the current byte_index in encoded_bytes vector (where the integer encoded begins, after the INTEGER_PREFIX).
    ///
    /// # Errors
    ///
    /// This function will return an error if the substring has a parse error.
    fn decode_integer(
        encoded_bytes: &[u8],
        i: usize,
    ) -> Result<(BencodeType, usize), TorrentError> {
        let len = i;
        let (integer, len) = Decoder::parse_int(encoded_bytes, len)?;
        Ok((integer.to_bencode_type(), len + 1))
    }

    /// This function parses the ByteString till len_string position.
    ///
    /// # Errors
    ///
    /// This function will return an error depending on the length string received.
    fn decode_string(encoded_bytes: &[u8], i: usize) -> Result<(BencodeType, usize), TorrentError> {
        let len = i;

        let (len_string, mut len) =
            Decoder::find_and_drain_substring(encoded_bytes, &STRING_POSTFIX, len)?;
        len += 1; // string_postfix skiped
        match String::from_utf8(encoded_bytes[len..len + len_string].to_vec()) {
            Ok(substr) => Ok((substr.to_bencode_type(), len + len_string)),
            Err(_) => Ok((
                encoded_bytes[len..len + len_string].to_bencode_type(),
                len + len_string,
            )),
        }
    }
}

#[cfg(test)]
mod tests {
    use crate::bencode::bencode_type::{BencodeType, ByteString, ToBencodeType};
    use crate::bencode::decoder::Decoder;
    use std::collections::HashMap;

    #[test]
    fn decode_string_test() {
        let string1 = "4:spam".as_bytes();
        match Decoder::decode(string1) {
            Ok(val) => {
                assert_eq!("spam".to_bencode_type(), val)
            }
            Err(_) => assert!(false),
        }

        let string2 = "4:spamasd".as_bytes();
        match Decoder::decode(string2) {
            Ok(val) => assert_eq!("spam".to_bencode_type(), val),
            Err(_) => assert!(false),
        }

        let string3 = "-1:spamasd".as_bytes();
        match Decoder::decode(string3) {
            Ok(val) => assert_eq!("spam".to_bencode_type(), val),
            Err(_) => assert!(true),
        }

        let string4 = "x:spamasd".as_bytes();
        match Decoder::decode(string4) {
            Ok(val) => assert_eq!("spam".to_bencode_type(), val),
            Err(_) => assert!(true),
        }

        let string5 = "4xspamasd".as_bytes();
        match Decoder::decode(string5) {
            Ok(val) => assert_eq!("spam".to_bencode_type(), val),
            Err(_) => assert!(true),
        }
    }

    #[test]
    fn decode_integer_test() {
        let int1 = "i0e".as_bytes();
        match Decoder::decode(int1) {
            Ok(val) => assert_eq!((0 as i32).to_bencode_type(), val),
            Err(_) => assert!(false),
        }

        let int2 = "i758e".as_bytes();
        match Decoder::decode(int2) {
            Ok(val) => assert_eq!((758 as i32).to_bencode_type(), val),
            Err(_) => assert!(false),
        }

        let int3 = "ie".as_bytes();
        assert!(Decoder::decode(int3).is_err());

        let int4 = "i-e".as_bytes();
        assert!(Decoder::decode(int4).is_err());

        let int5 = "i-0e".as_bytes();
        assert!(Decoder::decode(int5).is_err());

        let int6 = "i-05e".as_bytes();
        assert!(Decoder::decode(int6).is_err());

        let int7 = "i05e".as_bytes();
        assert!(Decoder::decode(int7).is_err());

        let int8 = "ife".as_bytes();
        assert!(Decoder::decode(int8).is_err());

        let int9 = "i-5-4e".as_bytes();
        assert!(Decoder::decode(int9).is_err());

        let int10 = "i--54e".as_bytes();
        assert!(Decoder::decode(int10).is_err());

        let int11 = "i4020e".as_bytes();
        match Decoder::decode(int11) {
            Ok(val) => assert_eq!((4020 as i32).to_bencode_type(), val),
            Err(_) => assert!(false),
        }
    }

    #[test]

    fn decode_test() {
        let decode_string_type = "hello".to_bencode_type();
        match decode_string_type {
            BencodeType::ByteString(val) => match val {
                ByteString::Word(string) => assert_eq!(string, "hello".to_string()),
                ByteString::Pieces(_pieces) => assert!(false),
            },

            BencodeType::Integer(_) => assert!(false),
            BencodeType::List(_) => assert!(false),
            BencodeType::Dictionary(_) => assert!(false),
        }

        let list: Vec<BencodeType> = Vec::new();
        let decode_list_type: BencodeType = list.to_bencode_type();
        match decode_list_type {
            BencodeType::ByteString(_) => assert!(false),
            BencodeType::Integer(_) => assert!(false),
            BencodeType::List(val) => assert_eq!(val.len(), 0),
            BencodeType::Dictionary(_) => assert!(false),
        }

        let decode_integer_type = 75.to_bencode_type();
        match decode_integer_type {
            BencodeType::ByteString(_) => assert!(false),
            BencodeType::Integer(val) => assert_eq!(val, 75),
            BencodeType::List(_) => assert!(false),
            BencodeType::Dictionary(_) => assert!(false),
        }

        let dictionary: HashMap<String, BencodeType> = HashMap::new();
        let decode_dictionary_type: BencodeType = dictionary.to_bencode_type();
        match decode_dictionary_type {
            BencodeType::ByteString(_) => assert!(false),
            BencodeType::Integer(_) => assert!(false),
            BencodeType::List(_) => assert!(false),
            BencodeType::Dictionary(val) => assert_eq!(val.len(), 0),
        }
    }

    #[test]
    fn decoder_list_test() {
        let string_encoded = "l4:spami42ee".as_bytes();
        let list =
            vec!["spam".to_bencode_type(), (42 as usize).to_bencode_type()].to_bencode_type();
        match Decoder::decode(string_encoded) {
            Ok(list_decoded) => assert_eq!(list, list_decoded),
            Err(_) => assert!(false),
        }

        let string_encoded = "l4:spamd3:bar4:spamee".as_bytes(); // with hash in second position
        let mut map = HashMap::new();
        map.insert("bar".to_string(), "spam".to_bencode_type());
        let list = vec!["spam".to_bencode_type(), map.to_bencode_type()].to_bencode_type();
        match Decoder::decode(string_encoded) {
            Ok(list_decoded) => assert_eq!(list, list_decoded),
            Err(_) => assert!(false),
        }

        let string_encoded = "l4:spami42e".as_bytes();
        assert!(Decoder::decode(string_encoded).is_err());
    }

    #[test]
    fn decoder_dictionary_test() {
        let string_encoded = "d3:bar4:spam3:fooi42ee".as_bytes();
        let mut map = HashMap::new();
        let key1 = "bar".to_string();
        let value1 = "spam".to_bencode_type();
        let key2 = "foo".to_string();
        let value2 = (42 as usize).to_bencode_type();
        map.insert(key1, value1);
        map.insert(key2, value2);

        match Decoder::decode(string_encoded) {
            Ok(result) => assert_eq!(map.to_bencode_type(), result),
            Err(_) => assert!(false),
        }

        let string_encoded = "di42e3:bare".as_bytes(); // with integer key
        assert!(Decoder::decode(string_encoded).is_err());

        let string_encoded = "dd3:bar4:spam3:fooi42ee3:bare".as_bytes(); // with hash key
        assert!(Decoder::decode(string_encoded).is_err());

        let string_encoded = "dli32ee3:bare".as_bytes(); // with list key
        assert!(Decoder::decode(string_encoded).is_err());

        let string_encoded = "d3:bar4:spam3:fooi42e".as_bytes(); // with list key
        assert!(Decoder::decode(string_encoded).is_err());
    }
}
