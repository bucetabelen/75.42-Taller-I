use std::env;

use rusty_krab_torrent::configuration::client_configuration::decode_configuration_file;
use rusty_krab_torrent::torrent::files::read_arguments;
use rusty_krab_torrent::torrent::metainfo::MetaInfo;
use rusty_krab_torrent::torrent::torrent_file::Torrent;
use rusty_krab_torrent::tracker::peer::Peer;
use rusty_krab_torrent::tracker::{
    peer_connection::PeerConnection, tracker_response::retrieve_peers,
};
use rusty_krab_torrent::utils::methods::create_peer_id;

const CONFIGURATION_TEST_PATH: &str = "test_files/test_configuration.yaml";
const LOCALHOST: &str = "127.0.0.1";
pub fn main() {
    let args: Vec<String> = env::args().collect();

    let filenames = read_arguments(args).unwrap();
    let metainfo = MetaInfo::read(&filenames[0]).unwrap();

    let config = decode_configuration_file(CONFIGURATION_TEST_PATH).unwrap();

    let client_peer_id = create_peer_id();
    let mut client =
        Peer::new_with_peer_id(config.port as usize, LOCALHOST.to_string(), client_peer_id)
            .unwrap();

    println!("Client created with peer id: {}\n", client.peer_id);

    let tracker = retrieve_peers(&metainfo, &client).unwrap();

    match Torrent::new(&client.peer_id, metainfo, config.download_path) {
        Ok(mut torrent) => {
            for peer in tracker.peers {
                match PeerConnection::connect_to_peer(peer, &mut client, &mut torrent) {
                    Ok(_) => {
                        break;
                    }
                    Err(error) => {
                        println!("{}", error);
                    }
                }
            }
            println!("You may use your file! ;)");
        }
        Err(error) => println!("{}", error),
    }
}
