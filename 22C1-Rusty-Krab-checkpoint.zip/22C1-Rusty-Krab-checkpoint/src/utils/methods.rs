use std::collections::HashMap;

use rand::{distributions::Alphanumeric, thread_rng, Rng};

use crate::bencode::bencode_type::{BencodeType, FromBencodeType};

use super::error::{MetainfoError, TorrentError};

pub const HTTP: &str = "http:";
pub const HTTPS: &str = "https:";
pub const ANNOUNCE: &str = "announce";
pub const EMPTY: &str = "";

/// Used in to_bencode_type to convert optional fields to BencodeType and insert them into the dictionary

#[macro_export]
macro_rules! string_optional {
    ($t:expr,$hm:expr,$($x:ident),*) => {
        $(match $t.$x {
            Some(ref string) => {

                $hm.insert(String::from(stringify!($x)).replace("_"," "), string.clone().to_bencode_type());},
            None => {},
        })*
    }
}

/// This function checks if the key passed in the argument exists in the Hashmap also passed in the argument.
/// If the key exists, it returns the BencodeType value refered to that key. If not, it returns a message wrapped in an error.
/// Note that is only used to search for the Info struct.

pub fn get_info_dictionary(
    hm: &HashMap<String, BencodeType>,
    key: &str,
) -> Result<BencodeType, TorrentError> {
    match hm.get(key) {
        Some(ben) => Ok(ben.to_owned()),
        None => Err(TorrentError::MetainfoError(MetainfoError::InfoNotFound)),
    }
}

/// The function get_value is pretty much the same as get_info_dictionary with a subtle change, it
/// returns an Option value as all the other elements in Metainfo can be Some or None, but not the Info element
///
pub fn get_value<T: FromBencodeType>(hm: &HashMap<String, BencodeType>, key: &str) -> Option<T> {
    hm.get(key)
        .map(|bencode_type| T::from_bencode_type(bencode_type).unwrap())
}

/// Used to transform Vec<Vec<u8>> into Vec<u8> format.

pub fn to_vec_utf8(pieces: &[Vec<u8>]) -> Vec<u8> {
    let mut vec = Vec::<u8>::new();
    for i in pieces {
        vec.extend_from_slice(i);
    }
    vec
}

/// This function gets the info value within the bencoded string as bytes.
/// It is used to make the info hash.
///
pub fn get_info_bytes(string: &str, splitter: &str) -> Vec<u8> {
    let iterator = string.split(splitter);
    let mut info_bytes = vec![0_u8];
    for str in iterator {
        if str.contains("pieces") {
            println!("{}", str);
            info_bytes = str.as_bytes().to_vec();
        }
    }
    info_bytes
}

/// Creates a 20 byte random string for peer id
pub fn create_peer_id() -> String {
    let random_chars: String = thread_rng()
        .sample_iter(&Alphanumeric)
        .take(20)
        .map(char::from)
        .collect();

    random_chars
}

/// Parses a &[u8; 4] (&[0, 1, 0, 1] for example) vec to u32. Only for length = 4.
/// This function only works with length = 4!
pub fn parse_vec_u8_into_u32(bytes: &[u8]) -> u32 {
    ((bytes[0] as u32) << 24)
        + ((bytes[1] as u32) << 16)
        + ((bytes[2] as u32) << 8)
        + (bytes[3] as u32)
}

/// Encodes parameters into a url
///
/// # Example
/// ```
/// # //use tracker;
/// //let params: Vec<(&str, &str)> = vec![("peer_id", "l33t"), ("port", "8080")];
/// //assert_eq!("peer_id=l33t&port=8080".to_string(), parameterize(params));
/// ```
pub fn parameterize(parameters: Vec<(&str, &str)>) -> String {
    let query_params: Vec<String> = parameters
        .iter()
        .map(|&kv| format!("{}={}", kv.0, kv.1))
        .collect();

    query_params.join("&")
}

/// Gets the port from the domain if it exists.
pub fn get_port(domain: &str) -> Vec<&str> {
    let info: Vec<&str> = domain.split(':').collect();
    info
}

/// Returns tuple which contains the announce and the port (or none, if port is not contain in the announce).
pub fn get_domain(announce: &str) -> (&str, Option<&str>) {
    let iter = announce.split('/');
    let mut domain = Vec::new();
    for s in iter {
        if s != HTTP && s != HTTPS && s != ANNOUNCE && s != EMPTY {
            domain = get_port(s);
        }
    }
    if domain.len() == 1 {
        return (domain[0], None);
    }
    (domain[0], Some(domain[1]))
}

/// given an array of bytes convert it to a url string.
/// in case of unrecognizable characters it leaves them in a hexadecimal pair.
/// Hex pair format example %00 = 0, %ff = 255
pub fn get_url_encode(info: &[u8]) -> String {
    let url: String = info
        .iter()
        .map(|byte| {
            let c = *byte as char;
            if ('a'..='z').contains(&c)
                || ('A'..='Z').contains(&c)
                || ('0'..='9').contains(&c)
                || c == '.'
                || c == '-'
                || c == '_'
                || c == '~'
            {
                String::from(c)
            } else {
                format! {"%{:02x?}",byte}
            }
        })
        .collect();
    url
}

/// remove http header of tracker response
pub fn remove_header(buffer: &mut Vec<u8>) -> Vec<u8> {
    let mut count = 0;
    for i in buffer.windows(4) {
        count += 1;
        if i.iter().zip(b"\r\n\r\n").all(|(a, b)| *a == *b) {
            break;
        };
    }
    buffer.drain(0..count + 4);
    if buffer[0] != b'd' {
        buffer.insert(0, b'd');
        buffer.push(b'e');
    }
    buffer.to_vec()
}

#[cfg(test)]
mod tests {
    use crate::utils::methods::{
        get_info_bytes, get_port, get_url_encode, parameterize, parse_vec_u8_into_u32, to_vec_utf8,
    };

    #[test]
    fn parse_vec_u8_into_u32_test() {
        let vec1: &[u8] = &[0, 0, 0, 1];
        let vec2: &[u8] = &[0, 0, 1, 0];
        let vec3: &[u8] = &[0, 1, 1, 0];

        let expected_vec1_parsed: u32 = 1;
        let expected_vec2_parsed: u32 = 256;
        let expected_vec3_parsed: u32 = 65792;

        let vec1_parsed = parse_vec_u8_into_u32(vec1);
        let vec2_parsed = parse_vec_u8_into_u32(vec2);
        let vec3_parsed = parse_vec_u8_into_u32(vec3);

        assert_eq!(vec1_parsed, expected_vec1_parsed);
        assert_eq!(vec2_parsed, expected_vec2_parsed);
        assert_eq!(vec3_parsed, expected_vec3_parsed);
    }

    #[test]
    fn to_vec_utf8_test() {
        let vec0: Vec<Vec<u8>> = vec![vec![0, 1, 5, 8], vec![0, 1, 5, 8], vec![0, 1, 5, 8]];
        assert_eq!(vec![0, 1, 5, 8, 0, 1, 5, 8, 0, 1, 5, 8], to_vec_utf8(&vec0));
        let vec1: Vec<Vec<u8>> = Vec::new();
        assert!(to_vec_utf8(&vec1).is_empty());
    }

    #[test]
    fn get_info_bytes_test() {
        assert_eq!(vec![0], get_info_bytes("hola mundo", " "));
        assert_eq!(
            vec![112, 105, 101, 99, 101, 115, 109, 117, 110, 100, 111],
            get_info_bytes("pieces hola piecesmundo", " ")
        );
        assert_eq!(
            vec![112, 105, 101, 99, 101, 115],
            get_info_bytes("pieces hola pieces mundo", " ")
        );
    }

    #[test]
    fn parameterize_test() {
        assert_eq!(
            "hola=mundo".to_string(),
            parameterize(vec![("hola", "mundo")])
        );
        assert_eq!("".to_string(), parameterize(Vec::new()));
        assert_eq!(
            "hola=mundo&prueba=0".to_string(),
            parameterize(vec![("hola", "mundo"), ("prueba", "0")])
        );
    }

    #[test]
    fn get_port_test() {
        assert_eq!(vec!["hola", "mundo"], get_port("hola:mundo"));
        assert_eq!(vec![""], get_port(""));
        assert_eq!(vec!["hola mundo"], get_port("hola mundo"));
    }

    #[test]
    fn get_url_encode_test() {
        assert_eq!(
            "a%00%01%ff%0f%f0".to_string(),
            get_url_encode(&vec![97, 0, 1, 255, 15, 240])
        );
        assert_eq!(
            "aaaaa".to_string(),
            get_url_encode(&vec![97, 97, 97, 97, 97])
        );
        assert_eq!(
            "zzazz".to_string(),
            get_url_encode(&vec![122, 122, 97, 122, 122])
        );
        assert_eq!("".to_string(), get_url_encode(&vec![]));
        assert_eq!(".-_~".to_string(), get_url_encode(&vec![46, 45, 95, 126]));
    }
}
