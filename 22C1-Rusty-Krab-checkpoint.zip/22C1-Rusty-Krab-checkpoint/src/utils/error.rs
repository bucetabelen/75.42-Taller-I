use native_tls::HandshakeError;
use std::{
    fmt,
    net::{AddrParseError, TcpStream},
};

#[derive(Debug)]
pub enum TorrentError {
    ConfigError(ConfigError),
    DecoderError(DecoderError),
    IOError(std::io::Error),
    UTFError(std::str::Utf8Error),
    HandshakeError(HandshakeError<TcpStream>),
    NotEnoughArguments,
    ParseIntegerError(std::num::ParseIntError),
    NoPieces,
    BencodeConversionError(String),
    MetainfoError(MetainfoError),
    MessageError(MessageError),
    PeerConnectionError(PeerConnectionError),
    TrackerError(TrackerError),
    DownloadPathError(String),
}

#[derive(Debug, Clone)]
pub enum DecoderError {
    PostfixReached,
    PostfixNotFound,
    ParseIntegerError,
    ByteStringLengthParseError,
    InvalidByteStringLength,
    CharNotValid,
    DictKeyIsNotString,
}

#[derive(Debug, Clone)]
pub enum MetainfoError {
    AnnounceNotFound,
    NotDictionary,
    InfoNotDictionary,
    InfoNotFound,
    FilePathNotFound,
    FileNotList,
}

#[derive(Debug, Clone)]
pub enum ConfigError {
    SeparatorNotFoundError,
    KeyNotFound,
}

#[derive(Debug)]
pub enum MessageError {
    InvalidId,
    InvalidProtocol,
    InvalidLength,
}

#[derive(Debug)]
pub enum PeerConnectionError {
    BadConnection,
    ErrorReadingResponse,
    ErrorSendingHandshake,
    ErrorSendingMessage,
    InfoHashNotServing,
    PeerIdNotMatch,
    BadResponse,
}

#[derive(Debug)]
pub enum TrackerError {
    TlsConnector(native_tls::Error),
    IPAddrError(AddrParseError),
    PeersNotFound,
    PeersFormatError,
}

impl fmt::Display for TorrentError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            TorrentError::ConfigError(ConfigError::KeyNotFound) => {
                write!(f, "ConfigError: Key not found")
            }
            TorrentError::ConfigError(ConfigError::SeparatorNotFoundError) => {
                write!(f, "ConfigError: Separator not found")
            }
            TorrentError::DecoderError(DecoderError::PostfixReached) => {
                write!(f, "DecoderError: Postfix reached")
            }
            TorrentError::DecoderError(DecoderError::PostfixNotFound) => {
                write!(f, "DecoderError: Postfix not found")
            }
            TorrentError::DecoderError(DecoderError::ParseIntegerError) => {
                write!(f, "DecoderError: Parse integer error")
            }
            TorrentError::DecoderError(DecoderError::ByteStringLengthParseError) => {
                write!(f, "DecoderError: ByteString length parse error")
            }
            TorrentError::DecoderError(DecoderError::CharNotValid) => {
                write!(f, "DecoderError: Char not valid")
            }
            TorrentError::DecoderError(DecoderError::InvalidByteStringLength) => {
                write!(f, "DecoderError: Invalid ByteString length")
            }
            TorrentError::DecoderError(DecoderError::DictKeyIsNotString) => {
                write!(f, "DecoderError: Dict key is not string")
            }
            TorrentError::IOError(err) => write!(f, "{}", err),
            TorrentError::TrackerError(TrackerError::TlsConnector(err)) => write!(f, "{}", err),
            TorrentError::TrackerError(TrackerError::IPAddrError(err)) => write!(f, "{}", err),
            TorrentError::UTFError(err) => write!(f, "{}", err),
            TorrentError::HandshakeError(err) => write!(f, "{}", err),
            TorrentError::NotEnoughArguments => write!(f, "Not enough arguments"),
            TorrentError::ParseIntegerError(err) => write!(f, "{}", err),
            TorrentError::NoPieces => write!(f, "Metainfo file has no pieces"),
            TorrentError::BencodeConversionError(string) => {
                write!(f, "Conversion error: {:?}", string)
            }
            TorrentError::MetainfoError(MetainfoError::AnnounceNotFound) => {
                write!(f, "MetainfoError: Announce url not found")
            }
            TorrentError::MetainfoError(MetainfoError::NotDictionary) => {
                write!(f, "MetainfoError: Metainfo not encoded as dictionary")
            }
            TorrentError::MetainfoError(MetainfoError::InfoNotDictionary) => {
                write!(f, "MetainfoError: Info not encoded as dictionary")
            }
            TorrentError::MetainfoError(MetainfoError::InfoNotFound) => {
                write!(f, "MetainfoError: Info not found in Metainfo dictionary")
            }
            TorrentError::MetainfoError(MetainfoError::FilePathNotFound) => {
                write!(f, "MetainfoError: Files path not found")
            }
            TorrentError::MetainfoError(MetainfoError::FileNotList) => {
                write!(f, "MetainfoError: Files not encoded as list")
            }
            TorrentError::MessageError(message_error) => {
                write!(f, "MessageError: {}", message_error)
            }
            TorrentError::PeerConnectionError(message_error) => {
                write!(f, "PeerConnection Error: {}", message_error)
            }
            TorrentError::TrackerError(TrackerError::PeersNotFound) => {
                write!(f, "TrackerError: Peers not found in tracker response")
            }
            TorrentError::TrackerError(TrackerError::PeersFormatError) => {
                write!(f, "TrackerError: Peers not List nor ByteString(Pieces)")
            }
            TorrentError::DownloadPathError(path) => {
                write!(f, "DownloadPathError: RustyKrab doesn't have permissions to create a new folder in {:?}",path)
            }
        }
    }
}

impl fmt::Display for DecoderError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            DecoderError::PostfixReached => write!(f, "Postfix reached"),
            DecoderError::PostfixNotFound => write!(f, "Postfix not found"),
            DecoderError::ParseIntegerError => write!(f, "Parse integer error"),
            DecoderError::ByteStringLengthParseError => write!(f, "ByteString length parse error"),
            DecoderError::CharNotValid => write!(f, "Char not valid"),
            DecoderError::InvalidByteStringLength => write!(f, "Invalid ByteString length"),
            DecoderError::DictKeyIsNotString => write!(f, "Dict key is not string"),
        }
    }
}

impl fmt::Display for MessageError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            MessageError::InvalidId => write!(f, "Invalid message id"),
            MessageError::InvalidLength => write!(f, "Invalid message length"),
            MessageError::InvalidProtocol => write!(f, "Wrong message length"),
        }
    }
}

impl fmt::Display for PeerConnectionError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            PeerConnectionError::BadConnection => write!(f, "Bad connection with peer"),
            PeerConnectionError::ErrorReadingResponse => write!(f, "Error reading peer response"),
            PeerConnectionError::ErrorSendingHandshake => {
                write!(f, "Error sending handshake message")
            }
            PeerConnectionError::PeerIdNotMatch => {
                write!(f, "Peer id received doesn't match with expected peer id")
            }
            PeerConnectionError::InfoHashNotServing => {
                write!(f, "Info hash received not currently serving")
            }
            PeerConnectionError::BadResponse => write!(f, "Bad peer response"),
            PeerConnectionError::ErrorSendingMessage => write!(f, "Error sending message"),
        }
    }
}

impl From<std::io::Error> for TorrentError {
    fn from(err: std::io::Error) -> Self {
        TorrentError::IOError(err)
    }
}

impl From<std::str::Utf8Error> for TorrentError {
    fn from(err: std::str::Utf8Error) -> Self {
        TorrentError::UTFError(err)
    }
}

impl From<std::num::ParseIntError> for TorrentError {
    fn from(err: std::num::ParseIntError) -> Self {
        TorrentError::ParseIntegerError(err)
    }
}

impl From<native_tls::Error> for TorrentError {
    fn from(err: native_tls::Error) -> Self {
        TorrentError::TrackerError(TrackerError::TlsConnector(err))
    }
}

impl From<HandshakeError<TcpStream>> for TorrentError {
    fn from(err: HandshakeError<TcpStream>) -> Self {
        TorrentError::HandshakeError(err)
    }
}

impl From<AddrParseError> for TorrentError {
    fn from(err: AddrParseError) -> Self {
        TorrentError::TrackerError(TrackerError::IPAddrError(err))
    }
}

impl std::error::Error for TorrentError {}
