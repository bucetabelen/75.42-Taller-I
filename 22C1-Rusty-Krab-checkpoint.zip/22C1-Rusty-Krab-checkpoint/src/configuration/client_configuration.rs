use super::super::{
    torrent::files::read_file,
    utils::error::{ConfigError, TorrentError},
};
use std::collections::HashMap;
use std::str;

const CONFIG_SEPARATOR: char = ':';
const LINE_SEPARATOR: char = '\n';
const SPACE_SEPARATOR: char = ' ';
const EMPTY: &str = "";
const CONFIG_KEY: &str = "configuration";
const PORT_KEY: &str = "port";
const LOG_KEY: &str = "log";
const DOWNLOAD_KEY: &str = "download";

/// Configuration struct saves the client information for the listening port, logging path and downloading path so it is easier
/// to reach to those values from the configuration.yaml

#[derive(Debug)]
pub struct Configuration {
    pub port: usize,
    pub log_path: String,
    pub download_path: String,
}

impl Configuration {
    pub fn new(port: usize, log_path: String, download_path: String) -> Configuration {
        Configuration {
            port,
            log_path,
            download_path,
        }
    }
}

/// This function reads the contents of the configuration file into a buffer, then passes it to string and replace the spaces with empty values.

pub fn read_configuration(config_path: &str) -> Result<String, TorrentError> {
    let buffer = read_file(config_path)?;
    let string = str::from_utf8(&buffer)?;
    let clean_string = string.replace(SPACE_SEPARATOR, EMPTY);
    Ok(clean_string)
}

/// Function to search for a specific value inside the dictionary created from the configuration file. It returns the value as a String

fn get_dict_value<'a>(
    dict: &'a HashMap<String, String>,
    key: &str,
) -> Result<&'a String, TorrentError> {
    match dict.get(key) {
        Some(value) => Ok(value),
        None => Err(TorrentError::ConfigError(ConfigError::KeyNotFound)),
    }
}

/// Function that inserts the keys and values of the configuration file into the mutable dictionary passed as parameter.
/// For example, the port:8080 line in the file will be parsed into (key:port, value:8080) element of the dictionary.

pub fn parse_configuration_file(
    config: &mut String,
    dict: &mut HashMap<String, String>,
) -> Result<(), TorrentError> {
    config.remove(0);
    let key = drain_info(config, CONFIG_SEPARATOR)?;
    let clean_key = key.replace(LINE_SEPARATOR, EMPTY);
    let value = drain_info(config, LINE_SEPARATOR);
    match value {
        Ok(value) => {
            let clean_value = value.replace(CONFIG_SEPARATOR, EMPTY);
            dict.insert(clean_key, clean_value);
            parse_configuration_file(config, dict)?;
            Ok(())
        }
        // I reached the end of the config file
        Err(_err) => {
            let clean_value = config.replace(CONFIG_SEPARATOR, EMPTY);
            dict.insert(clean_key, clean_value);
            Ok(())
        }
    }
}

/// Given a separator (char), it returns the value after the separator within a mutable String. It returns error in case the separator wasn't found

pub fn drain_info(config: &mut String, separator: char) -> Result<String, TorrentError> {
    let key_size = config.find(separator);
    match key_size {
        Some(len) => Ok(config.drain(..len).collect()),
        None => Err(TorrentError::ConfigError(
            ConfigError::SeparatorNotFoundError,
        )),
    }
}

/// This function creates the dictionary (Hashmap<String,String>) element where the configuration information is saved first. It calls the read_configuration,
/// parse_configuration_file and get_dict_value to create the Configuration struct and return it.

pub fn decode_configuration_file(config_path: &str) -> Result<Configuration, TorrentError> {
    println!("Reading configuration file from path {}\n", config_path);

    let mut config = read_configuration(config_path)?;
    let key = drain_info(&mut config, CONFIG_SEPARATOR)?;
    let mut dictionary = HashMap::<String, String>::new();
    match key.as_str() {
        CONFIG_KEY => {
            parse_configuration_file(&mut config, &mut dictionary)?;
            let port = get_dict_value(&dictionary, PORT_KEY)?.parse::<usize>()?;
            let log_path = get_dict_value(&dictionary, LOG_KEY)?.to_string();
            let download_path = get_dict_value(&dictionary, DOWNLOAD_KEY)?.to_string();
            println!("Reading configuration file: Ok!\n");
            Ok(Configuration {
                port,
                log_path,
                download_path,
            })
        }
        _ => Err(TorrentError::ConfigError(ConfigError::KeyNotFound)),
    }
}

impl PartialEq for Configuration {
    fn eq(&self, other: &Self) -> bool {
        (self.port == other.port)
            && (self.log_path == other.log_path)
            && (self.download_path == other.download_path)
    }
}

#[cfg(test)]
mod tests {

    use std::collections::HashMap;

    use super::{
        decode_configuration_file, drain_info, get_dict_value, parse_configuration_file,
        read_configuration, Configuration, CONFIG_SEPARATOR,
    };
    const CONFIGURATION_TEST_PATH: &str = "test_files/test_configuration.yaml";
    const CONFIGURATION_TEST_PATH_NON_EXISTENT: &str = "test_files/file_non_existent.yaml";
    const CONFIGURATION_TEST_PATH_ERROR: &str = "test_files/test_configuration_error.yaml";

    #[test]
    fn test_drain_info() {
        let mut test_string_ok = "port:80".to_string();
        let mut test_string_error = "port80".to_string();
        let key = "port".to_string();

        match drain_info(&mut test_string_ok, CONFIG_SEPARATOR) {
            Ok(string) => assert_eq!(string, key),
            Err(_) => assert!(false),
        }

        assert!(drain_info(&mut test_string_error, CONFIG_SEPARATOR).is_err())
    }

    #[test]
    fn test_get_dict_value() {
        let test_key_ok = "port".to_string();
        let test_key_error = "log".to_string();
        let test_value = "80";

        let mut dict = HashMap::<String, String>::new();
        dict.insert("port".to_string(), "80".to_string());

        let value = get_dict_value(&dict, &test_key_ok);

        match value {
            Ok(value) => assert_eq!(value, test_value),
            Err(_) => assert!(false),
        }

        assert!(get_dict_value(&dict, &test_key_error).is_err());
    }

    #[test]
    fn test_reading_of_configuration() {
        let config = read_configuration(CONFIGURATION_TEST_PATH);
        let test_config_ok =
            "configuration:\nport:80\nlog:test_files\ndownload:test_files".to_string();

        match config {
            Ok(config) => assert_eq!(config, test_config_ok),
            Err(_) => assert!(false),
        }

        assert!(read_configuration(CONFIGURATION_TEST_PATH_NON_EXISTENT).is_err());
    }

    #[test]
    fn test_parse_configuration() {
        let mut test_config = ":\nport:80\nlog:test_files\ndownload:test_files".to_string();
        let mut dict = HashMap::<String, String>::new();

        let mut mock_dict = HashMap::<String, String>::new();
        mock_dict.insert("port".to_string(), "80".to_string());
        mock_dict.insert("log".to_string(), "test_files".to_string());
        mock_dict.insert("download".to_string(), "test_files".to_string());

        match parse_configuration_file(&mut test_config, &mut dict) {
            Ok(_) => assert_eq!(dict, mock_dict),
            Err(_) => assert!(false),
        }
    }

    #[test]
    fn test_decode_configuration() {
        let mock_configuration = Configuration::new(
            "80".parse::<usize>().unwrap(),
            "test_files".to_string(),
            "test_files".to_string(),
        );

        match decode_configuration_file(CONFIGURATION_TEST_PATH) {
            Ok(configuration) => assert_eq!(configuration, mock_configuration),
            Err(_) => assert!(false),
        }

        assert!(decode_configuration_file(CONFIGURATION_TEST_PATH_ERROR).is_err());
    }
}
